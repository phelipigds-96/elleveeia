export interface CartItem {
  productId: string
  name: string
  quantity: number
  unitPrice?: number
  subtotal?: number
  priceType?: string
  lastPricingQueryId?: string
  isPriceConfirmed: boolean
}

export interface DiscoveredProduct {
  id: string
  name: string
  unitPrice?: number
  subtotal?: number
  brand?: string | null
}

export interface WorkingMemory {
  activeProduct?: {
    id: string
    name: string
  }
  activePrice?: {
    unitPrice: number
    priceType?: string
  }
  activeQuantity?: number
  activeCart?: CartItem[]
  activeQuote?: {
    id: string
    total: number
    status: string
  }
  discoveredProducts?: DiscoveredProduct[]
  updatedAt?: string
  expiredAt?: string
}

export interface AddCartItemParams {
  productId: string
  name: string
  quantity: number
  unitPrice?: number
  subtotal?: number
  priceType?: string
  lastPricingQueryId?: string
  isPriceConfirmed?: boolean
}

export interface CartCalculationResult {
  total: number
  itemCount: number
  allPricesConfirmed: boolean
  unconfirmedProductIds: string[]
}

/**
 * Adiciona um item ao carrinho ou atualiza um item existente.
 * Regras:
 * - Adicionar um segundo produto não apaga o primeiro.
 * - Adicionar o mesmo produto atualiza sua quantidade sem duplicar.
 * - Se a quantidade mudar sem novo preço confirmado, invalida o preço definitivo.
 * - Valores não validados não são aceitos como preço confirmado.
 */
export function addItemToCart(
  memory: WorkingMemory | null | undefined,
  item: AddCartItemParams
): WorkingMemory {
  const next: WorkingMemory = { ...(memory || {}) }
  const currentCart: CartItem[] = next.activeCart ? [...next.activeCart] : []

  if (!item.productId || typeof item.productId !== 'string' || item.productId.trim() === '') {
    throw new Error('productId inválido para adicionar ao carrinho.')
  }
  if (!item.name || typeof item.name !== 'string' || item.name.trim() === '') {
    throw new Error('Nome do produto inválido para adicionar ao carrinho.')
  }
  if (typeof item.quantity !== 'number' || !Number.isInteger(item.quantity) || item.quantity <= 0) {
    throw new Error(`Quantidade inválida (${item.quantity}). Deve ser um número inteiro positivo.`)
  }

  const pId = item.productId.trim()
  const pName = item.name.trim()

  const hasValidPrice = typeof item.unitPrice === 'number' && Number.isFinite(item.unitPrice) && item.unitPrice > 0
  const isConfirmed = hasValidPrice && item.isPriceConfirmed !== false

  const existingIndex = currentCart.findIndex(i => i.productId === pId)

  if (existingIndex >= 0) {
    const existing = currentCart[existingIndex]
    const quantityChanged = existing.quantity !== item.quantity

    const updatedItem: CartItem = {
      ...existing,
      name: pName,
      quantity: item.quantity,
      priceType: item.priceType ?? existing.priceType,
      lastPricingQueryId: item.lastPricingQueryId ?? existing.lastPricingQueryId
    }

    if (hasValidPrice && item.isPriceConfirmed) {
      updatedItem.unitPrice = item.unitPrice
      updatedItem.subtotal = typeof item.subtotal === 'number'
        ? Math.round(item.subtotal * 100) / 100
        : Math.round(item.unitPrice! * item.quantity * 100) / 100
      updatedItem.isPriceConfirmed = true
    } else if (quantityChanged) {
      // Invalidação determinística de preço: mudança de quantidade sem nova precificação
      updatedItem.isPriceConfirmed = false
      delete updatedItem.subtotal
    }

    currentCart[existingIndex] = updatedItem
  } else {
    const newItem: CartItem = {
      productId: pId,
      name: pName,
      quantity: item.quantity,
      priceType: item.priceType,
      lastPricingQueryId: item.lastPricingQueryId,
      isPriceConfirmed: isConfirmed
    }

    if (isConfirmed && hasValidPrice) {
      newItem.unitPrice = item.unitPrice
      newItem.subtotal = typeof item.subtotal === 'number'
        ? Math.round(item.subtotal * 100) / 100
        : Math.round(item.unitPrice! * item.quantity * 100) / 100
    }

    currentCart.push(newItem)
  }

  next.activeCart = currentCart
  next.updatedAt = new Date().toISOString()
  return next
}

/**
 * Atualiza a quantidade de um item no carrinho.
 * Invalida o preço definitivo anterior (isPriceConfirmed = false) para exigir nova precificação.
 */
export function updateCartItemQuantity(
  memory: WorkingMemory | null | undefined,
  productId: string,
  quantity: number
): WorkingMemory {
  const next: WorkingMemory = { ...(memory || {}) }
  if (!next.activeCart || next.activeCart.length === 0) return next

  if (typeof quantity !== 'number' || !Number.isInteger(quantity) || quantity <= 0) {
    throw new Error(`Quantidade inválida (${quantity}). Deve ser um número inteiro positivo.`)
  }

  const pId = productId.trim()
  const index = next.activeCart.findIndex(i => i.productId === pId)
  if (index === -1) return next

  const existing = next.activeCart[index]
  if (existing.quantity === quantity) return next

  const updatedCart = [...next.activeCart]
  const updatedItem: CartItem = {
    ...existing,
    quantity,
    isPriceConfirmed: false // Alteração de quantidade invalida o preço definitivo anterior
  }
  delete updatedItem.subtotal
  updatedCart[index] = updatedItem

  next.activeCart = updatedCart
  next.updatedAt = new Date().toISOString()
  return next
}

/**
 * Atualiza o preço validado de um item no carrinho.
 */
export function updateCartItemPrice(
  memory: WorkingMemory | null | undefined,
  productId: string,
  pricing: {
    unitPrice: number
    subtotal?: number
    priceType?: string
    lastPricingQueryId?: string
  }
): WorkingMemory {
  const next: WorkingMemory = { ...(memory || {}) }
  if (!next.activeCart || next.activeCart.length === 0) return next

  if (typeof pricing.unitPrice !== 'number' || !Number.isFinite(pricing.unitPrice) || pricing.unitPrice <= 0) {
    throw new Error(`Preço unitário inválido (${pricing.unitPrice}). Deve ser um número positivo.`)
  }

  const pId = productId.trim()
  const index = next.activeCart.findIndex(i => i.productId === pId)
  if (index === -1) return next

  const existing = next.activeCart[index]
  const subtotal = typeof pricing.subtotal === 'number'
    ? Math.round(pricing.subtotal * 100) / 100
    : Math.round(pricing.unitPrice * existing.quantity * 100) / 100

  const updatedCart = [...next.activeCart]
  updatedCart[index] = {
    ...existing,
    unitPrice: pricing.unitPrice,
    subtotal,
    priceType: pricing.priceType ?? existing.priceType,
    lastPricingQueryId: pricing.lastPricingQueryId ?? existing.lastPricingQueryId,
    isPriceConfirmed: true
  }

  next.activeCart = updatedCart
  next.updatedAt = new Date().toISOString()
  return next
}

/**
 * Remove um item do carrinho, preservando todos os demais.
 */
export function removeCartItem(
  memory: WorkingMemory | null | undefined,
  productId: string
): WorkingMemory {
  const next: WorkingMemory = { ...(memory || {}) }
  if (!next.activeCart) return next

  const pId = productId.trim()
  next.activeCart = next.activeCart.filter(item => item.productId !== pId)
  next.updatedAt = new Date().toISOString()
  return next
}

/**
 * Consulta todos os itens do carrinho.
 */
export function getCartItems(memory: WorkingMemory | null | undefined): CartItem[] {
  return memory?.activeCart ? [...memory.activeCart] : []
}

/**
 * Calcula o subtotal consolidado do carrinho utilizando apenas valores validados.
 */
export function calculateCartTotal(memory: WorkingMemory | null | undefined): CartCalculationResult {
  const items = memory?.activeCart || []
  let totalCents = 0
  let allPricesConfirmed = true
  const unconfirmedProductIds: string[] = []

  for (const item of items) {
    if (item.isPriceConfirmed && typeof item.subtotal === 'number' && item.subtotal > 0) {
      totalCents += Math.round(item.subtotal * 100)
    } else {
      allPricesConfirmed = false
      unconfirmedProductIds.push(item.productId)
    }
  }

  return {
    total: totalCents / 100,
    itemCount: items.length,
    allPricesConfirmed: items.length > 0 ? allPricesConfirmed : true,
    unconfirmedProductIds
  }
}

/**
 * Constante padrão de expiração (TTL) da Working Memory Operacional (24 horas)
 */
export const DEFAULT_WORKING_MEMORY_TTL_MS = 24 * 60 * 60 * 1000

/**
 * Obtém o TTL configurado para o carrinho e memória de trabalho em milissegundos.
 * Permite customização por variável de ambiente AGENT_CART_TTL_HOURS (default: 24h).
 */
export function getConfiguredCartTtlMs(): number {
  const envHours = process.env.AGENT_CART_TTL_HOURS ? Number(process.env.AGENT_CART_TTL_HOURS) : null
  if (typeof envHours === 'number' && !isNaN(envHours) && envHours > 0) {
    return envHours * 60 * 60 * 1000
  }
  return DEFAULT_WORKING_MEMORY_TTL_MS
}

export interface WorkingMemoryExpiryOptions {
  /**
   * Se true, timestamps ausentes, vazios ou inválidos são tratados como expirados (Fail-Closed).
   * Padrão: false para retrocompatibilidade direta quando chamado sem opções.
   */
  failClosed?: boolean
}

/**
 * Verifica se a Working Memory expirou devido a inatividade prolongada (> TTL).
 * Aceita timestamp ISO, Date ou milissegundos.
 * Quando options.failClosed for true, timestamps ausentes ou inválidos retornam true (expirados por segurança).
 */
export function isWorkingMemoryExpired(
  timestamp: string | Date | number | null | undefined,
  now: number = Date.now(),
  ttlMs: number = getConfiguredCartTtlMs(),
  options?: WorkingMemoryExpiryOptions
): boolean {
  if (!timestamp) return Boolean(options?.failClosed)
  const timeMs = typeof timestamp === 'number'
    ? timestamp
    : new Date(timestamp).getTime()
  if (isNaN(timeMs)) return Boolean(options?.failClosed)
  return (now - timeMs) > ttlMs
}

/**
 * Reseta deterministicamente os dados voláteis da Working Memory (carrinho não finalizado,
 * produto em foco e buffer de buscas anteriores), preservando apenas histórico
 * estritamente permanente.
 */
export function expireWorkingMemory(
  memory: WorkingMemory | null | undefined,
  nowIso: string = new Date().toISOString()
): WorkingMemory {
  if (!memory) return {}
  const next: WorkingMemory = { ...memory }
  delete next.activeCart
  delete next.activeProduct
  delete next.activePrice
  delete next.activeQuantity
  delete next.discoveredProducts
  // Se o orçamento era um rascunho (draft) não finalizado, expira junto com o carrinho
  if (next.activeQuote?.status === 'draft') {
    delete next.activeQuote
  }
  next.expiredAt = nowIso
  next.updatedAt = nowIso
  return next
}

/**
 * Limpa todos os itens do carrinho em memória.
 */
export function clearCart(memory: WorkingMemory | null | undefined): WorkingMemory {
  const next: WorkingMemory = { ...(memory || {}) }
  next.activeCart = []
  next.updatedAt = new Date().toISOString()
  return next
}

/**
 * Atualiza deterministicamente a Working Memory a partir dos resultados reais das ferramentas executadas.
 */
export function applyWorkingMemoryUpdate(previous: WorkingMemory | null | undefined, toolResults: any[]): WorkingMemory {
  let next: WorkingMemory = { ...(previous || {}) }
  let hasValidToolResult = false

  for (const res of toolResults) {
    if (!res || !res.success || !res.data) continue
    hasValidToolResult = true

    const toolName = res.toolName
    
    if (toolName === 'buscar_produto' || toolName === 'consultar_produto_comercial') {
      // 1. Atualizar buffer contínuo de produtos descobertos/apresentados (discoveredProducts)
      const incomingProducts: DiscoveredProduct[] = []
      if (Array.isArray(res.data.products)) {
        for (const p of res.data.products) {
          if (p?.id && p?.name) {
            incomingProducts.push({
              id: p.id,
              name: p.name,
              unitPrice: p.price?.unit_price ?? p.unit_price ?? p.unitPrice,
              subtotal: p.price?.subtotal ?? p.subtotal,
              brand: p.brand || null
            })
          }
        }
      } else if (res.data.product?.id && res.data.product?.name) {
        incomingProducts.push({
          id: res.data.product.id,
          name: res.data.product.name,
          unitPrice: res.data.price?.unit_price ?? res.data.pricing?.unit_price ?? res.data.unit_price,
          subtotal: res.data.price?.subtotal ?? res.data.pricing?.subtotal ?? res.data.subtotal,
          brand: res.data.product.brand || null
        })
      } else if (Array.isArray(res.data.matches)) {
        for (const m of res.data.matches) {
          if (m?.id && m?.name) {
            incomingProducts.push({
              id: m.id,
              name: m.name,
              unitPrice: m.price?.unit_price ?? m.unit_price,
              brand: m.brand || null
            })
          }
        }
      }

      if (incomingProducts.length > 0) {
        const existingList = next.discoveredProducts ? [...next.discoveredProducts] : []
        const mergedIncoming: DiscoveredProduct[] = incomingProducts.map(inc => {
          const old = existingList.find(e => e.id === inc.id)
          return old ? { ...old, ...inc } : inc
        })
        const incomingIds = new Set(mergedIncoming.map(p => p.id))
        const remaining = existingList.filter(e => !incomingIds.has(e.id))
        // Produtos recém-apresentados ou atualizados sempre no topo (mais recentes primeiro)
        next.discoveredProducts = [...mergedIncoming, ...remaining].slice(0, 20)
      }



      const isConfirmedMatch = 
        res.data.strategy === 'specific_product' ||
        res.data.strategy === 'quantity_pricing' ||
        res.data.status === 'exact_match'

      if (isConfirmedMatch) {
        const product = res.data.product ?? res.data.matches?.[0]
        
        if (product && typeof product.id === 'string' && product.id.trim() !== '' && typeof product.name === 'string' && product.name.trim() !== '') {
          const newId = product.id.trim()
          
          // Invalidação de dependências: se o produto mudou para outro ID, descartamos os derivados antigos
          if (next.activeProduct && next.activeProduct.id !== newId) {
            delete next.activePrice
            delete next.activeQuantity
          }
          
          next.activeProduct = { id: newId, name: product.name.trim() }
        }

        // Atualiza quantidade se a ferramenta comercial confirmou uma quantidade válida
        if (typeof res.data.quantity === 'number' && res.data.quantity > 0) {
          next.activeQuantity = res.data.quantity
        }

        // Aplica preço novo se houver
        const pricingData = res.data.pricing ?? res.data.price
        if (pricingData) {
          const unitPrice = pricingData.unit_price ?? pricingData.unitPrice
          const priceType = pricingData.price_type ?? pricingData.priceType
          if (typeof unitPrice === 'number') {
            next.activePrice = { unitPrice, priceType }
          }
        }

        // Regra do Carrinho: se a estratégia for explicitamente de quantidade (quantity_pricing),
        // o cliente solicitou uma quantidade específica com precificação confirmada, sincronizamos o item no carrinho.
        // Consultas puras de produto (specific_product, exact_match sem quantidade) NÃO inserem no carrinho automaticamente.
        if (res.data.strategy === 'quantity_pricing' && next.activeProduct && typeof next.activeQuantity === 'number' && next.activePrice) {
          const subtotal = pricingData?.subtotal ?? Math.round(next.activePrice.unitPrice * next.activeQuantity * 100) / 100
          next = addItemToCart(next, {
            productId: next.activeProduct.id,
            name: next.activeProduct.name,
            quantity: next.activeQuantity,
            unitPrice: next.activePrice.unitPrice,
            subtotal,
            priceType: next.activePrice.priceType,
            isPriceConfirmed: true
          })
        }
      }
    }
    
    if (toolName === 'calcular_preco_produto') {
      if (typeof res.data.quantity === 'number' && res.data.quantity > 0) {
        next.activeQuantity = res.data.quantity
      }
      
      const unitPrice = res.data.unit_price ?? res.data.unitPrice
      const priceType = res.data.price_type ?? res.data.priceType
      if (typeof unitPrice === 'number') {
        next.activePrice = { unitPrice, priceType }
      }

      const prodId = res.data.product_id ?? next.activeProduct?.id
      if (prodId) {
        const prodName = res.data.product_name ?? 
          next.discoveredProducts?.find(p => p.id === prodId)?.name ?? 
          (next.activeProduct && next.activeProduct.id === prodId ? next.activeProduct.name : undefined) ??
          next.activeCart?.find(i => i.productId === prodId)?.name

        if (prodName && typeof unitPrice === 'number') {
          const qty = res.data.quantity ?? next.activeQuantity ?? 1
          const subtotal = res.data.subtotal ?? Math.round(unitPrice * qty * 100) / 100
          next = addItemToCart(next, {
            productId: prodId,
            name: prodName,
            quantity: qty,
            unitPrice,
            subtotal,
            priceType,
            isPriceConfirmed: true
          })
          next.activeProduct = { id: prodId, name: prodName }
        } else if (next.activeCart?.some(i => i.productId === prodId)) {
          next = updateCartItemPrice(next, prodId, {
            unitPrice,
            subtotal: res.data.subtotal,
            priceType
          })
        }
      }
    }

    if (toolName === 'consultar_preco') {
      const unitPrice = res.data.unit_price ?? res.data.unitPrice
      const priceType = res.data.price_type ?? res.data.priceType
      if (typeof unitPrice === 'number') {
        next.activePrice = { unitPrice, priceType }
      }

      const prodId = res.data.product_id ?? next.activeProduct?.id
      if (prodId && next.activeCart?.some(i => i.productId === prodId)) {
        const item = next.activeCart.find(i => i.productId === prodId)
        if (item && item.quantity === 1) {
          next = updateCartItemPrice(next, prodId, {
            unitPrice,
            priceType
          })
        }
      }
    }

    if (toolName === 'gerar_orcamento' || toolName === 'consultar_orcamento') {
      if (res.data.id) {
        next.activeQuote = { 
          id: res.data.id, 
          total: typeof res.data.total === 'number' ? res.data.total : 0, 
          status: res.data.status || 'draft' 
        }
      }

      // Se o orçamento foi gerado ou consultado com sucesso e retornou itens confirmados,
      // sincronizamos o activeCart com a composição do orçamento
      if (Array.isArray(res.data.items) && res.data.items.length > 0) {
        const existingCart = next.activeCart || []
        const quoteItems: CartItem[] = res.data.items.map((it: any) => {
          const pId = it.productId ?? it.product_id
          const existingItem = existingCart.find(e => e.productId === pId)
          return {
            productId: pId,
            name: it.productName ?? it.name ?? existingItem?.name ?? (next.activeProduct && next.activeProduct.id === pId ? next.activeProduct.name : 'Produto'),
            quantity: it.quantity,
            unitPrice: it.unitPrice ?? it.unit_price,
            subtotal: it.subtotal,
            priceType: it.priceType ?? it.price_type ?? existingItem?.priceType,
            isPriceConfirmed: true
          }
        })
        next.activeCart = quoteItems
      }
    }
  }

  if (hasValidToolResult) {
    next.updatedAt = new Date().toISOString()
  } else if (!next.updatedAt && (Boolean(next.activeCart?.length) || Boolean(next.activeProduct) || Boolean(next.activePrice) || Boolean(next.activeQuote))) {
    // Garante que qualquer memória operacional com dados ativos possua timestamp inicial
    next.updatedAt = new Date().toISOString()
  }
  
  return next
}
